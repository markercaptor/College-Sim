#include <iostream>
#include <fstream>
#include <string>
#include <unistd.h>
#include <iomanip>
#include <cstdlib>

using namespace std;

void splash();
int mainMenu();
int highScores(int newScore, string newName);
int game();

int main()
{
	bool endGame = false;
	for (int i = 0; i < 100; i++) cout << endl; // clears the screen
		
	splash();
	
	do //menu loop
	{
		switch(mainMenu())  
		{
			case 3:
				cout << "That's a horrible idea. I'm sending you now.\n";
			case 1:
				if (game() == 0) endGame = true;
				break;
			case 2:
				if (highScores(-1,"null") == 0) endGame = true;
				break;
			case 4:
				endGame = true;
				break;
			default:
				cout << " \n\n\n\n Invalid choice.\n\n";
		}
	} while (endGame == false);
	
	cout << endl << endl << endl;
	return 0;
}

void splash()
{
	ifstream splashFile;
	string splash[100] ={};
	int i=0;
	
	splashFile.open ("splash.txt"); 
	if (!splashFile) // verifies splash.txt is open
	{
		cout << "splash.txt not found" << endl;
		exit(EXIT_FAILURE);
	}
	while(getline(splashFile, splash[i])) //displays splash screen
	{
		cout << splash[i] << endl;
		usleep(100000);
		i++;
	}
	splashFile.close();
	
	usleep (1000000);
	
	cout << endl << endl << endl;
}

int mainMenu()
{
	int menuChoice;
	
	//text color options
	char blue[] = { 0x1b, '[', '1', ';', '3', '4', 'm', 0 };
	char normal[] = { 0x1b, '[', '0', ';', '3', '9', 'm', 0 };
	char green[] = { 0x1b, '[', '1', ';', '3', '2', 'm', 0 };
	char yellow[] = { 0x1b, '[', '1', ';', '3', '3', 'm', 0 };
	char red[] = { 0x1b, '[', '1', ';', '3', '1', 'm', 0 };
	
	
	cout<< "***********************************************************************\n"
		<< "*                                                                     *\n"
		<< "*                                                                     *\n"
		<< "*           First Year College Simulator:                             *\n"
		<< "*                                                                     *\n"
		<< "*                          Infected Edition                           *\n"
		<< "*                                                                     *\n"
		<< "*                                      By: Quantum Games              *\n"
		<< "*                                                                     *\n"
		<< "*  "<<green<<"1. Play the game   "<<blue<<"2. Highscores  "<<yellow<<"3. Take a Year Off  "<<red<<"4. Quit"<<normal<<"      *\n"
		<< "***********************************************************************\n"
		<<endl<<endl<<endl;
		 
	cout <<"Enter your choice: ";
	cin >> menuChoice;
	
	return menuChoice;
	
}

int highScores(int newScore, string newName)
{
	
	string name[10] = {};
	int score[10] = {};
	char endGame;
	ifstream inHighScores;
	ofstream outHighScores;
	
	inHighScores.open ("highScores.txt"); 
	if (!inHighScores) // verifies highScores.txt is open
	{
		cout << "highScores.txt not found" << endl;
		exit(EXIT_FAILURE);
	}
	
	for (int i = 0; i < 10; i++) //reads scores
	{
		inHighScores >> name[i] >> score[i];
	}
	inHighScores.close();
	
	if (newScore == -1) //displays scores
	{
		cout << ("Highscores: \n\n");
		for(int i = 0; i < 10; i++)
			cout << name[i] << "\t" << score[i] << endl;
	}
	
	else if ( newScore > score[9]) //sorts/saves scores
	{
		int i = 9;

		while(i >= 0 && newScore > score[i])
		{	
			if (i == 9) i--;
			else
			{ 
				name[i+1] = name[i];
				score[i+1] = score[i--];	
			}
		}
		score[i+1] = newScore; 
		name[i+1] = newName;
		
		outHighScores.open ("highScores.txt");
		
		for (int i = 0; i < 10; i++) //save scores
		{
			outHighScores << name[i] << " " << score[i] << endl;
		}
		outHighScores.close();
		
	}
	if (newScore == -1) // check to see if called from main menu
	{
		do //retun to menu?
		{
			cout << "\nReturn to menu? (y/n) ";
			cin >> endGame;
		}while (endGame != 'y' && endGame != 'n');
	}
	
	
	
	if (endGame == 'y') return 1; 
	else return 0;
}

int game()
{
	char endGame;
	int Score = 0, plot = 1, choice;
	string newName;
	
	cout << "Enter you name: ";
	cin >> newName;
	
	cout << endl<<endl<<endl;
	
	while(plot != -1)
	{
		
		cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
		
		switch (plot)
		{
			case 1:
				do // choice
				{
					cout << "You got accepted into Texas A&M Corpus Christi and moved in three days ago. \n\nYou wake up on the first day of class.\n\n"
						 << "1. Get up and go to class.\n2. Sleep for five more minutes.\n3. Go back home and drop out.\n4. Skip the first day.\n\n"
						 << "What do you do? ";
					cin >> choice;
				}while (choice < 0 || choice > 4);
				
				switch (choice) // result
				{
					case 1:
						plot = 10;
						Score += 100;
						break;
					case 2:
						plot = 101;
						Score += 80;
						break;
					case 3:
						plot = 102;
						Score -= 50;
						break;
					case 4:
						plot = 103;
						Score += 10;
						break;
				}
				break;
				
			case 10:
				do // choice
				{
					cout << "You get up and get ready to go to class …\n";
					cout << "You are now on campus trying to find your classes.\n\n";
					cout << "1. Wander blindly in hopes of finding them.\n2. Look at a map of the campus.\n3. Ask a person if they can show you.\n\n";
					cout << "What do you do? ";
					cin >> choice;
				}while (choice < 0 || choice > 3); 
				
				switch (choice) //result
				{
					case 1:
						plot = 11;
						break;
					case 2:
						plot = 12;
						break;
					case 3:
						plot = 13;
						break;
				}
				break;
			case 101:
			do // choice
				{
					cout << "You sleep for five more minutes.\n\n";
					cout << "1. Sleep for five more minutes.\n";
					cout << "2. Get up and go to class.\n\n";
					cout << "What do you do? ";
					cin >> choice;
				}while (choice < 0 || choice > 2); 
				
				switch (choice) //result
				{
					case 1:
						plot = 110;
						break;
					case 2:
						plot = 10;
						break;
				}
				break;
				
			case 102:
				cout << "You decide to go back home and drop out of college before even going to your first class.\n";
				cout << "Good job, your journey ends here.\n\n";
				plot = -1;
				break;
				
			case 104:
			do // choice
				{
					cout << "You lounge around not doing anything and proceed on \nto bed as you wasted the day with nothing to do.\n";
					cout << "The next day comes and you wake up. \n\n";
					cout << "1. Go to class like you should.  \n2. Drop out because at this point you aren’t going to go to class at all.\n\n";
					cout << "What do you do? ";
					cin >> choice;
				}while (choice < 0 || choice > 2); 
				
				switch (choice) //result
				{
					case 1:
						plot = 111;
						break;
					case 2:
						plot = 112;
						break;
				}
				break;
				
			case 11:
				cout << "You never find your classes and decide to drop out.\n\n";
				plot = -1;
				break;
				
			case 110:
			do // choice
				{
					cout << "You realize you’ll be late if you keep sleeping. \n\n";
					cout << "1. Keep sleeping\n";
					cout << "2. Get up and go to class.\n\n";
					cout << "What do you do? ";
					cin >> choice;
				}while (choice < 0 || choice > 2); 
				
				switch (choice) //result
				{
					case 1:
						plot = 1110;
						break;
					case 2:
						plot = 10;
						break;
				}
				break;
				
			case 1110:
			do // choice
				{
					cout << "You decide to sleep in and skip your first class.\nDo you skip all your classes? \n\n";
					cout << "1. Yes\n";
					cout << "2. No\n\n";
					cout << "What do you do? ";
					cin >> choice;
				}while (choice < 0 || choice > 2); 
				
				switch (choice) //result
				{
					case 1:
						plot = 1111;
						break;
					case 2:
						plot = 10;
						break;
				}
				break;
				
			case 1111:
				cout << "You skipped all your classes on your first day.\n";
				cout << "Congratulations.\n";
				cout << "You repeat this pattern every day until you flunk out.\n";
				cout << "Your college career is over.\n\n";
				plot = -1;
				break;
				
			case 111: 
			do // choice
				{
					cout << "You make it to the school and realize just how empty everything is \n";
					cout << "and wander the campus looking for signs of people. \n";
					cout << "Then you see a group of them and head towards them \n";
					cout << "and notice they are not moving around. \n\n";
					cout << "1. walk towards them and see what is going on. \n2. Stay away because they are strangers and that is scary. \n3. \n\n";
					cout << "What do you do? ";
					cin >> choice;
				}while (choice < 0 || choice > 3); 
				
				switch (choice) //result
				{
					case 1:
						plot =121 ;
						break;
					case 2:
						plot = 122;
						break;
				}
				break;
			case 112:
				cout << "Congratulations you failed at college.\n";
				plot = -1;
				break;
			case 12:
				do
				{
					cout << "You look at the campus map and spot where your first class is and head off to class.\n";
					cout << "The day goes on and you manage to go to all your classes and head back home for the day.\n";
					cout << "Now you are in your apartment and you remember you need to read some chapters.\n\n";
					cout << "1. Read the chapters then go to bed.\n2. Just go to bed and worry about it later.\n\n";
					cout << "What will you do? ";
					cin >> choice;
				}while (choice < 0 || choice > 3);
				
				switch (choice)
				{
					case 1:
						plot = 14;
						Score += 100;
						break;
					case 2:
						plot = 15;
						Score += 10;
						break;
				}
				break;
				
			case 121:
			do
				{
					cout << "You walk towards them and suddenly they notice you as you try to say something. \n";
					cout << "As the first word leaves your lips they charge at you and you take off running. \n";
					cout << "Eventually you lose them and are wondering what is happening. \n\n";
					cout << "1. Just go to class and pretend nothing happened.\n2. Find the authorities and report what happened. \n\n";
					cout << "What will you do? ";
					cin >> choice;
				}while (choice < 0 || choice > 2);
				
				switch (choice)
				{
					case 1:
						plot = 151;
						Score += 100;
						break;
					case 2:
						plot = 152;
						Score += 10;
						break;
				}
				break;
				
			case 122:
				cout << "Good job you remember what your parents taught you.\n";
				plot = 151;
				cout << "\nPress <Enter> to continue...";
				cin.get();
				break;
				
			case 13:
			do
				{
					cout << "You ask the nearest person to help you find your classes and they oblige.\n";
					cout << "After they get you to your first class they advise you to look at the map next time you get lost.\n";
					cout << "Classes go well and you are now in your dorm realizing there are chapters you need to read.\n\n";
					cout << "1. Read the chapters then go to bed.\n2. Just go to bed and worry about it later.";
					cout << "What do you do? ";
					cin >> choice;
				}while (choice < 0 || choice > 2);
				
				switch (choice)
				{
					case 1:
						plot = 14;
						Score += 100;
						break;
					case 2:
						plot = 15;
						Score += 10;
						break;
				}
				break;
				
			case 14:
				do
				{
					cout << "You read your chapters then head to bed feeling good about doing your homework.\n";
					cout << "The second day of classes starts, and you wake up and go to class.\n";
					cout << "You are in class and some people come up to you and start talking to you and ask if you want to study with them after class.\n\n";
					cout << "1. Yeah that would be great.\n2. No I’m good.\n3. Not today, but maybe some other time.\n\n";
					cout << "What will you say? ";
					cin >> choice;
				}while (choice < 0 || choice > 3);
				
				switch (choice)
				{
					case 1:
						plot = 16;
						Score += 100;
						break;
					case 2:
						plot = 17;
						Score += 10;
						break;
					case 3:
						plot = 17;
						Score += 50;
						break;
				}
				break;
			
			case 151:
			do
				{
					cout << "You head to class trying to forget what you saw,\n, but when you get there the room is empty and now you are worried\nworried because at this point you are ten minutes late and no one is here.\n\n";
					cout << "1. Try going to the next class.\n2. Sit around and hope someone shows up.\n\n";
					cin >> choice;
				}while (choice < 0 || choice > 2);
				
				switch (choice)
				{
					case 1:
						plot = 170 ;
						Score += 100;
						break;
					case 2:
						plot = 171;
						Score += 10;
						break;

				}
				break;
				
			case 152:
				cout << "You look around and find no one to report this to.\n";
				plot = 151;
				cout << "\nPress <Enter> to continue...";
				cin.get();
				break;
				
			case 15:
			do
				{
					cout << "You go to bed exhausted by the day, but have a nagging at the back\n";
					cout << "of your mind because you did not take care of what you should have.\n";
					cout << "The second day of classes starts, and you wake up and go to class.";
					cout << "You are in class and some people come up to you and start talking to you\n";
					cout << "and ask if you want to study with them after class.\n\n";
					cout << "1. Yeah that would be great.\n2. No I’m good.\n3. Not today, but maybe some other time.\n\n";
					cout << "What will you say? ";
					cin >> choice;
				}while (choice < 0 || choice > 4);
				
				switch (choice)
				{
					case 1:
						plot = 16;
						Score += 100;
						break;
					case 2:
						plot = 17;
						Score += 10;
						break;
					case 3:
						plot = 17 ;
						Score += 50;
						break;
				}
				break;
				
			case 16:
				do
				{
					cout << "You go to the study session and realize that you really get along with these people.\n";
					cout << "Time passes. \n";
					cout << "You head home and realize you already have everything done for the night,\n so you head off to bed early.\n";
					cout << "Third day of classes and you wake up and notice everything seems unusually quiet.\n";
					cout << "You disregard the lack of people where you live and head off to class.\n";
					cout << "When you get there, you see a mass of people stumbling around.\n\n";
					cout << "1. Go closer and try to find out what is going on.\n2. Stay back and go around them and try to get to class.\n\n";
					cout << "What do you do? ";
					cin >> choice;
				}while (choice < 0 || choice > 3);
				
				switch (choice)
				{
					case 1:
						plot = 19;
						Score += 50;
						break;
					case 2:
						plot = 20;
						Score += 100;
						break;
				}
				break;
				
			case 170:
				cout << "You open the door and an infected is behind the door.\n";
				cout << "Now you are infected all because you did not check before opening the door.";
				plot = -1;
				break;
				
			case 17:
			do
				{
					cout << "The people walk away wishing you would have come along,\n";
					cout << "but you now know there names and consider them friends.\n";
					cout << "You head home and realize you already have everything done for the night\n";
					cout << "so head off to bed early.\n";
					cout << "Third day of classes and you wake up and notice everything seems unusually quiet.\n";
					cout << "You disregard the lack of people where you live and head off to class.\n";
					cout << "When you get there, you see a mass of people stumbling around.\n\n";
					cout << "1. Go closer and try to find out what is going on.\n";
					cout << "2. stay back and go around them and try to get to class\n\n";
					cout << "What do you do? ";
					cin >> choice;
				}while (choice < 0 || choice > 2);
				
				switch (choice)
				{
					case 1:
						plot = 19;
						Score += 100;
						break;
					case 2:
						plot = 20;
						Score += 10;
						break;

				}
				break;
				
			case 171: 
			do
				{
					cout << "As you sit and wait you hear noises coming from outside the door. \nThe sounds grow louder and louder as they get closer. \n\n";
					cout << "1. Sit there and pretend nothing is there. \n";
					cout << "2. Hide under the desks in case it is more of those things from outside.";
					cout << "3. Go to the door and try to figure out what it is.\n\n";
					cout << "What do you do? ";
					cin >> choice;
				}while (choice < 0 || choice > 3);
				
				switch (choice)
				{
					case 1:
						plot =  200;
						Score += 100;
						break;
					case 2:
						plot = 201;
						Score += 10;
						break;
					case 3:
						plot = 202;
						Score += 10;
						break;
				}
				break;
				
			case 19:
				do
				{
					cout << "You start to inch closer and suddenly you are grabbed and \npulled into the engineering building.\n";
					cout << "It’s one of your friends she tells you not to go near people because \nit’s like they are zombies as they won’ respond to people, but simply stumble around \nand have a small chance to attack people.\n";
					cout << "Several thoughts run through your head.\n\n";
					cout << "1. Wait what do you mean like zombies that sounds close to zombies to me!\n2. Alright I get what you are saying what is our next move?\n3. I need a minute.\n4. This is really going to ruin my GPA!\n\n";
					cout << "which one will you express? ";
					cin >> choice;
				}while(choice < 0 || choice > 4);
				
				switch(choice)
				{
					case 1:
						plot = 21;
						Score += 10;
						break;
					case 2:
						plot = 22;
						Score +=20;
						break;
					case 3:
						plot = 23;
						Score += 30;
						break;
					case 4:
						plot = 24;
						Score += 40;
						break;
				}
				break;
				
			case 20:
			do
				{
					cout << "As you head around you see one of you friends from the study group you didn’t go to.\n";
					cout << "They say that you both need to get to class and avoid these things.\n";
					cout << "You agree and you both head off to get to class.\n";
					cout << "Most of the way is uneventful, but just before you get to class,\n";
					cout << "you realize that the door has a swarm of them outside of it. \n\n";
					cout << "1. Try to move through them.\n";
					cout << "2. Get them distracted and run past them.\n\n";
					cout << "What do you do? ";
					cin >> choice;
				}while (choice < 0 || choice > 2);
				
				switch (choice)
				{
					case 1:
						plot =  25;
						Score += 100;
						break;
					case 2:
						plot = 26 ;
						Score += 10;
						break;
				}
				break;
			case 200:
				cout << "Eventually as you sit there the noise goes away and you head for the door and see\n";
				cout << "that there is now nothing there and make your way to your next class.";
				plot = 221;
				cout << "\nPress <Enter> to continue...";
				cin.get();
				break; 
				
			case 201:
				cout << "You hide under the desk and do not move from this spot for the rest of the year\n";
				cout << "because you are too scared to see if the infected ever left.";
				plot = -1;
				break;
				
			case 202:
			do
				{
					cout << "You head towards the door and grab the door knob and open it just enough to see outside.\n";
					cout << "It seems empty, so you open the door all the way to look out into the hall fully.\n";
					cout << "As you look to your left you see a giant group of those things headed towards you.\n\n";
					cout << "1. Run and head back to your dorm and forget the day.\n";
					cout << "2. Try to get to the next class.\n";
					cout << "3. Stay in the classroom.\n\n";
					cin >> choice;
				}while(choice < 0 || choice > 5);
				
				switch(choice)
				{
					case 1:
						plot = 220;
						Score += 10;
						break;
					case 2:
						plot = 221;
						Score +=20;
						break;
					case 3:
						plot = 222;
						Score += 30;
						break;

				}
				break;
			case 21:
				do
				{
					cout << "You express your thought and your friend responds by saying that the professor’s said that we need to carry on like normal but be careful, so we are going to try and get to class.\n";
					cout << "You head out to try and get to class.\n";
					cout << "Most of the way is uneventful, but just before you get to class you realize that the door has a swarm of them outside of it.\n";
					cout << "Your friend asks what to do.\n\n";
					cout << "1. Try to move through them.\n2. Get them distracted and run past them.\n3. Just turn away and try the next class instead.\n\n";
					cout << "What is your choice? ";
					cin >> choice;
				}while(choice < 0 || choice > 4);
				
				switch(choice)
				{
					case 1:
						plot = 25;
						Score += 10;
						break;
					case 2:
						plot = 26;
						Score += 50;
						break;
					case 3:
						plot = 27;
						Score += 100;
						break;
				}
				break;
				
			case 22:
			case 220:
			case 221:
			do
				{
					cout << "You head out of the door hoping they do not notice you.\n";
					cout << "As you round the hall you see it is clear and head to the next class.\n";
					cout << "You make it there without seeing any more of those things.\n";
					cout << "When you get to the next class the professor and other people are there.\n";
					cout << "The weird part is that the professor is calm while the students are freaking out.\n\n";
					cout << "1. Ask the professor what is going on.\n";
					cout << "2. Take a seat and pretend that none of this is happening.\n";
					cout << "3. Accept what is happening and deal with it.\n\n";
					cout << "What do you do? ";
					cin >> choice;
				}while(choice < 0 || choice > 5);
				
				switch(choice)
				{
					case 1:
						plot = 280;
						Score += 10;
						break;
					case 2:
						plot = 281;
						Score +=20;
						break;
					case 3:
						plot = 282;
						Score += 30;
						break;

				}
				break;
			case 222:
			case 23:
			case 24:
			case 25:
			case 26:
				cout << "Your friend goes along with your plan but is reluctant.\n";
				cout << "Unfortunately, your plan fails.\n";
				cout << "Both of you are infected and can no longer function like normal\n";
				cout << "college students for the rest of the semester.";
				plot = -1;
				break;
				
			case 27:
				do
				{
					cout << "Your friend agrees that this would be the best option.\n";
					cout << "You manage to get to all of your classes and the professor’s act as if nothing is going on.\n";
					cout << "Time passes, and you manage to hold good grades despite the outbreak going on around you.\n";
					cout << "Everyone has learned how to cope with getting to classes and sort of avoid the students who are infected.\n";
					cout << "The time to register comes up and you don’t know what classes to pick.\n\n";
					cout << "1. Pick random classes.\n2. Schedule a meeting with academic advisor.\n3. Try to figure it out on your own.\n\n";
					cout << "What do you do? ";
					cin >> choice;
				}while(choice < 0 || choice > 3);
				
				switch(choice)
				{
					case 1:
						plot = 28;
						Score += 10;
						break;
					case 2:
						plot = 29;
						Score += 100;
						break;
					case 3:
						plot = 28;
						Score += 50;
						break;
				}
				break;
				
			case 28:
				cout << "You choose your classes to the best of your ability, but your choices don’t work best for you.\n";
				cout << "This will increase the number of years it will take to get your degree.\n";
				plot = -1;
			case 280:
			do
				{
					cout << "As you study like the professor told you the world seems to slip away as\n";
					cout << "for some reason this puts you at ease. You study for a while and feel accomplished\n";
					cout << "that you survived the first day and didn’t even have to think about where your classes\n";
					cout << "where because you visited them for two days prior to today.\n\n";
					cout << "1. Go to sleep.\n";
					cout << "2. Stay up all night\n\n";
					cout << "What do you do? ";
					cin >> choice;
				}while(choice < 0 || choice > 2);
				
				switch(choice)
				{
					case 1:
						plot = 300;
						Score += 10;
						break;
					case 2:
						plot = 301;
						Score +=20;
						break;
				}

			case 281:
			case 282:
			case 29:
				do
				{
					cout << "The meeting is set for two days from now.\n";
					cout << "You play getting to classes safe until your meeting.\n";
					cout << "Today is the day of the meeting.\n";
					cout << "You wake up and head to your advisor’s office.\n";
					cout << "Just before you get there you notice a group of the infected just outside the building, but it looks like you may be able to walk between them.\n\n";
					cout << "1. Walk between them.\n2. Try to find another way. \n\n";
					cout << "What do you do? ";
					cin >> choice;
				}while (choice < 0 || choice > 2);
				switch(choice)
				{
					case 1:
						plot = 31;
						Score += 50;
						break;
					case 2:
						plot = 32;
						Score += 100;
						break;
					}
				break;


			case 300:
			do
				{
					cout << "You go to sleep.\n";
					cout << "Roughly 3 months pass of you pretending nothing is going on and trying to go on about your school days.\n";
					cout << "Every day is the same consisting of you finding different ways to avoid the things at the school.\n";
					cout << "This day is different though on your way to your second class you notice that everything seems emptier than normal.\n";
					cout << "As you survey your surroundings you notice that everything is empty and shutdown. Except the round building to your right\n\n";
					cout << "1. Go to your next class.\n2. Head to the round building and try to find out what is going on.\n\n";
					cout << "What do you do? ";
					cin >> choice;
				}while(choice < 0 || choice > 2);
				
				switch(choice)
				{
					case 1:
						plot = 320;
						Score += 10;
						break;
					case 2:
						plot = 321;
						Score +=20;
						break;
				}
			case 301:
			case 31:
				do
				{
					cout << "You head off towards the group noticing the large gaps between them.\n";
					cout << "As you walk, you slip in between the gaps as smoothly as possible.\n";
					cout << "The door is now fully within site, but you accidentally bump into one of them.\n";
					cout << "The infected reacts to the touch and turns towards you.\n\n";
					cout << "1. Grab for the door.\n2. Stand still and hope nothing happens.\n\n";
					cout << "What action will you take? ";
					cin >> choice;
				}while (choice < 0 || choice > 2);
				
				switch (choice)
				{
					case 1:
						plot = 33;
						Score += 100;
						break;
					case 2:
						plot = 34;
						Score += 10;
						break;
				}
				break;
			
			case 32:
				do
				{
					cout << "You head away from the group looking or another door and find one without\n";
					cout << "any in front of it and head inside having avoided the possibility of getting infected.\n";
					cout << "You meet with the academic advisor and you get told what classes you should take.\n";
					cout << "Then you are asked if you have any questions some start to fill your head.\n\n";
					cout << "1. Have your heard anything about a cure for the infected or anything?\n";
					cout << "2. How have you been?\n";
					cout << "3. When do I need to register by?\n";
					cout << "4. Ask nothing.\n\n";
					cout << "What will you ask? ";
					cin >> choice;
				}while (choice < 0 || choice > 4);
				
				switch (choice)
				{
					case 1:
						plot = 35;
						Score += 100;
						break;
					case 2:
						plot = 36;
						Score += 50;
						break;
					case 3:
						plot = 37;
						Score += 75;
						break;
					case 4:
						plot = 38;
						Score += 10;
						break;
				}
				break;
			case 320:
			case 321:
			do
				{
					cout << "You head into the round building and speak to the only person there.\n\n";
					cout << "1. Why is everything so empty?\n2. How is your day?\n\n";
					cout << "What do you do? ";
					cin >> choice;
				}while(choice < 0 || choice > 2);
				
				switch(choice)
				{
					case 1:
						plot = 340;
						Score += 10;
						break;
					case 2:
						plot = 341;
						Score +=20;
						break;
			case 33:
				cout << "The infected see your movements and grab hold of you.\n";
				cout << "One of them bites you, causing you to become infected.\n\n";
				plot = -1;
			case 34:
				do
				{
					cout << "The infected stares at you for a moment then turns away and you bolt for the door getting inside.\n";
					cout << "You meet with the academic advisor and you get told what classes you should take.\n";
					cout << "Then you are asked if you have any questions some start to fill your head.\n\n";
					cout << "1. Have your heard anything about a cure for the infected or anything?\n";
					cout << "2. How have you been?\n";
					cout << "3. When do I need to register by?\n";
					cout << "4. Ask nothing.\n\n";
					cout << "What will you ask? ";
					cin >> choice;
				}while (choice < 0 || choice > 4);
				
				switch (choice)
				{
					case 1:
						plot = 35;
						Score += 100;
						break;
					case 2:
						plot = 36;
						Score += 50;
						break;
					case 3:
						plot = 37;
						Score += 75;
						break;
					case 4:
						plot = 38;
						Score += 10;
						break;
				}
				break;
				
			case 340:
			do
				{
					cout << "The man tells you that the school has just been rid of those things\n";
					cout << "and that the school is shut down and everything will be back to normal tomorrow.\n";
					cout << "He tells you to go home and forget the events of the past three months.\n\n";
					cout << "1. Go home and come back to school and forget the events that have transpired.\n2. Just not finish school.\n\n";
					cout << "What do you do? ";
					cin >> choice;
				}while(choice < 0 || choice > 2);
				
				switch(choice)
				{
					case 1:
						plot = 400;
						Score += 10;
						break;
					case 2:
						plot = 401 ;
						Score +=20;
						break;
				}
				
			case 341:
			case 35:
				do
				{
					cout << "The academic advisor tells you that to their understanding from rumors that the\ninfected are on a time limit of sorts and should hopefully be back to normal by the end of the semester.\n";
					cout << "You take this knowledge as hope because some of your friends have been infected by now.\n";
					cout << "After this you head back home and nothing eventful happens.\n";
					cout << "Time passes once again and this time it is now time for finals which means the end of the semester is soon.\n";
					cout << "You debate whether to study or try to see if anyone has turned back.\n\n";
					cout << "1. Stay and study to keep your GPA up.\n2. Go out and check.\n\n";
					cout << "Which will you do? ";
					cin >> choice;
				}while (choice < 0 || choice > 2);
				
				switch (choice)
				{
					case 1:
						plot = 39;
						Score =+ 100;
						break;
					case 2:
						plot = 40;
						Score += 20;
						break;
				}
				break;
			
			case 36:
				cout << "The advisor responds to your question by saying this is not the time for pleasantries.\n";
				cout << "The infected will be fine by the end of the semester that will be the time.\n";
				cout << "You ask about the infected.";
				plot = 35;
				cout << "\nPress <Enter> to continue...";
				cin.get();
			case 37:
				cout << "Your advisor shows you how to find the registration dedline on the college website.\n";
				cout << "You ask about the infected.";
				plot = 35;
				cout << "\nPress <Enter> to continue...";
				cin.get();
			case 38:
				cout << "You sit there in awkward silence and the advisor tells you to leave";
				cout << "You decide to ask about the infected.";
				plot = 35;
				cout << "\nPress <Enter> to continue...";
				cin.get();
			case 39:
				do
				{
					cout << "You study for several hours and eventually retire to bed.\n";
					cout << "Your head swirls with thoughts about everything that has happened this semester and eventually fall asleep.\n";
					cout << "You wake up and go to class and take your finals and wait on the scores which marks the actual end of the semester.\n";
					cout << "While you are lying in bed your phone lights up as black board notifies you about final grades.\n";
					cout << "You check, and you made all A’s. You are overly excited then the thought sinks in about your friends who are infected.\n";
					cout << "Then you remember that they could be back to normal because it is the end of the semester.\n\n";
					cout << "1. Go see if anyone has turned back.\n 2. Stay and accept that they are infected and will stay that way.\n\n";
					cout << "What will you do? ";
					cin >> choice;
				}while (choice < 0|| choice > 2);
				
				switch (choice)
				{
					case 1:
						plot = 41;
						Score += 100;
						break;
					case 2: 
						plot = 42;
						Score += 50;
						break;
				}
				break;
				case 40:
					cout << "You arrive at the school to see nothing has changed and you solemnly walk home\n";
					cout << "with the thought that they may never turn back. Then you proceed to head home.\n";
					plot = 39;
					cout << "\nPress <Enter> to continue...";
					cin.get();
					break;
				case 400:
					cout << "You go home and come back and then procced to have a successful four years of college and go onto live a happy life.\n\n";
					cout << "Yet always having that nagging thought in the back of your head. What exactly happened at school all those years ago?\n\n";
					cout << "You made it through college congratulations.\n\n";
					plot = -1;
					break;
				case 401:
				case 41:
					cout << "You rush off to campus, but when you arrive everyone seems the same no one has changed back.\n"
						<< "This saddens you and you go to return home as your only stayed to see if anyone would turn back,\n" 
						<< "but just before you are able to walk back to your car you hear your name.\n" 
						<< "It gets louder and louder and you turn around to see your friends who were infected rushing towards you\n"
						<< "and you then notice that everyone is starting to turn back to normal.\n\n\n"
						<< "Congratulation’s you survived your first year of college!\n";
					plot = -1;
					break;
				case 42:	
					cout << "You decide to stay and accept what has happened.\n";
					cout << "Several hours pass and suddenly there is a knock on your front door.\n";
					cout << "Thoughts run through your head that it was just your mid playing tricks on you.\n";
					cout << "The knocking gets progressively louder.\n";
					cout << "So, you finally go to the door and when you open it you see your friend standing there not infected anymore.\n";
					cout << "After this experience the rest of the year goes smoothly, and you finish with straight A’s.\n\n";
					cout << "Congratulations you survived your first year of college.";
					plot = -1;
					break;
			default:
				break;
		}
		}
	}

	

	highScores(Score, newName);
	
	
	
	
	cout << "Your score is: " << Score << endl;
	
		do //menu
		{
			cout << "\nReturn to menu? (y/n) ";
			cin >> endGame;
		}while (endGame != 'y' && endGame != 'n');	
	
	if (endGame == 'y') return 1; 
	else return 0;
}